Create a database 'blood_management-system'
Import the .sql file
Run the index.php file in browser

Login Details for admin
username = admin
password = admin

Login Details for donor(user)
username = sagar
password = sagar
